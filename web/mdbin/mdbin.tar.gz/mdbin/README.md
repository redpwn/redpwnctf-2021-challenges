# MdBin

A simple static-site-only pastebin for markdown content. Also supports customizable themes for pastes, currently in beta!

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Hacking

This project uses [yarn](https://classic.yarnpkg.com/lang/en) and standard Create React App scripts. To get started, install dependencies by running `yarn`, and then start up the development server by running `yarn start`. Generate a production build by running `yarn build`.
