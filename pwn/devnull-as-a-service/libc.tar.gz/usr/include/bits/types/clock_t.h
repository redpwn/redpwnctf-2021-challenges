#ifndef __clock_t_defined
#define __clock_t_defined 1

#include <bits/types.h>

/* Returned by `clock'.  */
typedef __clock_t clock_t;

#endif
